//
//  Superheroes.swift
//  Superheroes and Laureates app
//
//  Created by student on 4/13/19.
//  Copyright © 2019 student. All rights reserved.
//

import Foundation

class Superheros:Codable{
    var squadName : String
    var homeTown : String
    var formed : Int
    var secretBase : String
    var active : Bool
    var members : [Members]
}

class Members:Codable{
    var name:String
    var age:Int
    var secretIdentity:String
    var powers:[String]
}
