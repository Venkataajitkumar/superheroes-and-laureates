//
//  superherosTableViewController.swift
//  Superheroes and Laureates app
//
//  Created by student on 4/13/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class SuperherosTableViewController: UITableViewController {

    var superMembers:[String] = []
    var ListOfMembers : [Members] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        superHerosFetch()
    }
        
    func superHerosFetch(){
        let urlSession = URLSession.shared
        let url = URL(string: "https://mdn.github.io/learning-area/javascript/oojs/json/superheroes.json")
        urlSession.dataTask(with: url!, completionHandler: showSuperHeros).resume()
    }
    
    func showSuperHeros(data:Data?, urlResponse:URLResponse?, error:Error?)->Void {
        do {
            let decoder:JSONDecoder = JSONDecoder()
            let superheros = try decoder.decode(Superheros.self, from: data!)
            self.ListOfMembers = superheros.members
            DispatchQueue.main.async {
                self.tableView.reloadData()
                NotificationCenter.default.post(name: NSNotification.Name("superhero"), object: self.ListOfMembers)
            }
        } catch {
            print(error)
        }
    }

   
        

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "SUPERHEROS"
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ListOfMembers.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "superhero", for: indexPath)
        let superman = ListOfMembers[indexPath.row]
        self.superMembers = superman.powers
        var persons : String = ""
        for i in 0..<superMembers.count{
           // for i in 0 <superMembers.count{
           if i<superMembers.count-1 {
            //  persons = persons - "\(superMembers[i]),"
             persons = persons + "\(superMembers[i]),"
            }
            
//           else {
//            persons = persons - "\(superMembers[i])"
//            }
            
            else {
                persons = persons + "\(superMembers[i])"
            }
        }
        cell.textLabel?.text = "\(superman.name) (aka: \(superman.secretIdentity)) "
        cell.detailTextLabel?.text = persons

        return cell
    }

}
 
 
