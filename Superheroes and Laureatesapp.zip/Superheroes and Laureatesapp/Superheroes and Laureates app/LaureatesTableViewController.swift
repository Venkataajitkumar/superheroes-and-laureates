//
//  LaureatesTableViewController.swift
//  Superheroes and Laureates app
//
//  Created by student on 4/13/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class LaureatesTableViewController: UITableViewController {
    var laureatesLaur : [[String:Any]]!
    var laur01:[String:Any]!
    var laur02:[Laureates] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        laureatesFetch()
    
    }
    
    
        func laureatesFetch(){
        let urlSession = URLSession.shared
        let url = URL(string: "https://www.dropbox.com/s/7dhdrygnd4khgj2/laureates.json?dl=1")
        urlSession.dataTask(with: url!, completionHandler: laureatesDisplay).resume()
    }
    
    
    
            func laureatesDisplay(data:Data?, urlResponse:URLResponse?, error:Error?)->Void {
    
        do {
            try laureatesLaur = JSONSerialization.jsonObject(with:data!, options: .allowFragments) as?
                [[String:Any]]
                    for i in 0..<laureatesLaur.count
            {
                            laur01 = laureatesLaur[i]
                            let id = laur01["id"] as? String
                            let firstname = laur01["firstname"] as? String
                            let surname = laur01["surname"] as? String
                            let born = laur01["born"] as? String
                            let died = laur01["died"] as? String
                            laur02.append(Laureates(id: id, firstname: firstname, surname: surname, born: born, died: died))
            }
            
                    for laureat in laur02{
                print(laureat)
            }
                DispatchQueue.main.async {
                self.tableView.reloadData()
                NotificationCenter.default.post(name: NSNotification.Name("Laureates"), object: self.laureatesLaur)
            }
        } catch {
            print(error)
        }
    }
            override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "LAUREATES"
    }
    
            override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

            override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return laur02.count
    }

    
            override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "laureates", for: indexPath)
        let laurrr = laur02[indexPath.row]
        let tag = cell.viewWithTag(1) as! UILabel
        let tab = cell.viewWithTag(2) as! UILabel
                    tag.text = "\(laurrr.firstname ?? "NA") \(" ")\(laurrr.surname ?? "NA")"
      tab.text = "\(laurrr.born ?? "NA") \("-") \(laurrr.died ?? "NA")"

        return cell
    }
}





